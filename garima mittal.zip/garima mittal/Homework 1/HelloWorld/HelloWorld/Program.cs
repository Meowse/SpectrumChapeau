﻿using System;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("I deserve a pass credit for attempting this homework.");
            Console.ReadKey();
        }
    }
}
